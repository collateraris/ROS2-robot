# Недельный срез 04 из v5

Это самостоятельный накопительный проект: код недель 1..4. Распаковывать в отдельную папку, не поверх более позднего среза.

Из корня этой папки, на Ubuntu 24.04 с ROS 2 Jazzy:

```bash
bash scripts/install_system.sh sim
source /opt/ros/jazzy/setup.bash
# Если rosdep ещё не инициализирован: sudo rosdep init
rosdep update
rosdep install --from-paths ros2_ws/src --ignore-src -r -y --rosdistro jazzy
bash scripts/build_ros.sh all
bash scripts/setup_python.sh all cpu
source scripts/env_robot.sh
```

GPU-среда вместо CPU: следовать docs/INSTALL_RU.md, установить подходящий PyTorch и использовать setup_python.sh all existing.
Все пути установки в общей инструкции заменить на фактический корень этого среза.
Начать с docs/WEEK01_RU.md, затем последовательно до docs/WEEK04_RU.md. Критерии следующего этапа не пропускать.

Полная исходная поставка v5 содержит больше модулей. Недельный срез проверен на структуру, целостность и доступные импорты отдельно; он не является утверждением об исполненном ROS/Gazebo испытании.
